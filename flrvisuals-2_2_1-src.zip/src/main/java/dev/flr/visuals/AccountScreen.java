package dev.flr.visuals;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Переключатель оффлайн-аккаунтов в собственном оформлении. */
public class AccountScreen extends Screen {
    private static final int ROWS = 5, PW = 300;

    private final Screen parent;
    private String nick = "", status = "";
    private int offset, statusColor = 0x9094B4;

    public AccountScreen(Screen parent) {
        super(Component.literal("FLR Accounts"));
        this.parent = parent;
    }

    private int px() { return (width - PW) / 2; }
    private int ph() { return 104 + ROWS * 24 + 56; }
    private int py() { return Math.max(4, (height - ph()) / 2); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        Backdrop.draw(g, width, height);
        int px = px(), py = py(), ph = ph(), acc = Config.color() & 0xFFFFFF;
        Ui.rrect(g, px - 1, py - 1, PW + 2, ph + 2, 15, 0x50000000 | acc);
        Ui.rrect(g, px, py, PW, ph, 14, 0xF50E1019);
        Ui.bold(g, Tr.tr("Account switcher"), px + 14, py + 11, 0xFF000000 | acc);
        Ui.text(g, Tr.fmt("Current: %s", AccountManager.current()), px + 14, py + 24, 0xFFFFFFFF);
        Ui.text(g, AccountManager.isOriginalActive() ? Tr.tr("Original account") : Tr.tr("Offline account"), px + 14, py + 35, 0xFF6C7090);

        // поле ввода
        int fy = py + 60;
        Ui.rrect(g, px + 12, fy, PW - 112, 20, 10, 0xFF181A27);
        String shown = nick.isEmpty() ? Tr.tr("Nickname") : nick;
        Ui.text(g, shown, px + 22, fy + 6, nick.isEmpty() ? 0xFF5E6280 : 0xFFFFFFFF);
        if (!nick.isEmpty() && (System.currentTimeMillis() / 500) % 2 == 0) Ui.rrect(g, px + 23 + Ui.w(nick), fy + 5, 1, 10, 0, 0xFFFFFFFF);
        Ui.pill(g, px + PW - 92, fy, 80, 20, Tr.tr("Add & use"), Ui.in(mx, my, px + PW - 92, fy, 80, 20), true, acc);

        // список
        List<String> names = AccountManager.names();
        int y0 = py + 92;
        if (names.isEmpty()) Ui.text(g, Tr.tr("No saved accounts yet"), px + 14, y0 + 6, 0xFF6C7090);
        for (int i = 0; i < ROWS && offset + i < names.size(); i++) {
            String n = names.get(offset + i);
            int y = y0 + i * 24;
            boolean active = n.equals(AccountManager.current());
            Ui.rrect(g, px + 12, y, PW - 24, 20, 10, active ? 0x59000000 | acc : 0xFF181A27);
            Ui.text(g, n, px + 24, y + 6, active ? 0xFFFFFFFF : 0xFFB4B8D2);
            Ui.pill(g, px + PW - 84, y + 1, 44, 18, Tr.tr("Use"), Ui.in(mx, my, px + PW - 84, y + 1, 44, 18), false, acc);
            Ui.pill(g, px + PW - 34, y + 1, 18, 18, "X", Ui.in(mx, my, px + PW - 34, y + 1, 18, 18), false, 0xFF4D5E);
        }

        int sy = py + ph - 52;
        if (!status.isEmpty()) Ui.text(g, Ui.fit(status, PW - 24), px + 14, sy, 0xFF000000 | statusColor);
        Ui.text(g, Ui.fit(Tr.tr("Offline nicknames only. Premium servers will reject them."), PW - 24), px + 14, sy + 11, 0xFF5E6280);
        int by = py + ph - 28;
        Ui.pill(g, px + 12, by, 140, 20, Tr.tr("Original account"), Ui.in(mx, my, px + 12, by, 140, 20), false, acc);
        Ui.pill(g, px + PW - 92, by, 80, 20, Tr.tr("Back"), Ui.in(mx, my, px + PW - 92, by, 80, 20), false, acc);
    }

    private void addAndUse() {
        String n = nick.trim();
        if (!AccountManager.add(n)) {
            status = Tr.tr("Nickname: 3-16 letters, digits or _");
            statusColor = 0xFF7070;
            return;
        }
        nick = "";
        use(n);
    }

    private void use(String n) {
        AccountManager.switchTo(n);
        status = Tr.fmt("Now playing as %s (applies to the next server connection)", n);
        statusColor = 0x6FE09A;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (b != 0) return false;
        int px = px(), py = py(), ph = ph(), fy = py + 60, y0 = py + 92, by = py + ph - 28;
        if (Ui.in(mx, my, px + PW - 92, fy, 80, 20)) { addAndUse(); return true; }
        List<String> names = AccountManager.names();
        for (int i = 0; i < ROWS && offset + i < names.size(); i++) {
            String n = names.get(offset + i);
            int y = y0 + i * 24;
            if (Ui.in(mx, my, px + PW - 84, y + 1, 44, 18)) { use(n); return true; }
            if (Ui.in(mx, my, px + PW - 34, y + 1, 18, 18)) { AccountManager.remove(n); return true; }
        }
        if (Ui.in(mx, my, px + 12, by, 140, 20)) {
            AccountManager.restoreOriginal();
            status = Tr.fmt("Original account restored: %s", AccountManager.current());
            statusColor = 0x6FE09A;
            return true;
        }
        if (Ui.in(mx, my, px + PW - 92, by, 80, 20)) { onClose(); return true; }
        return super.mouseClicked(mx, my, b);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int max = Math.max(0, AccountManager.names().size() - ROWS);
        offset = Math.max(0, Math.min(max, offset - (int) Math.signum(sy)));
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (nick.length() < 16 && (Character.isLetterOrDigit(c) && c < 128 || c == '_')) {
            nick += c;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 259 && !nick.isEmpty()) { nick = nick.substring(0, nick.length() - 1); return true; }
        if (key == 257 || key == 335) { addAndUse(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
