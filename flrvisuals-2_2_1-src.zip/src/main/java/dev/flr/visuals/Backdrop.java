package dev.flr.visuals;

import java.util.Random;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/**
 * Фон главного меню: глубокий градиент, медленно плывущие светящиеся шары, шёлковые волны со светящимся гребнем,
 * мягкие лучи, мерцающая пыль и виньетка. Всё гладкое (сглаженные формы), стиль выбирается в настройках.
 */
final class Backdrop {
    private static final String[] TIPS = {
            "Press the menu key to open FLR settings.", "Pets look where you look.",
            "Try the Snow weather in the Atmosphere tab.", "Target ESP shows a rotating reticle on your target.",
            "Right-click a feature to open its settings.", "Put .ogg or .wav files into flrvisuals/music to play them.",
            "Black and white are available in every colour list."};
    private static final int N = 110;
    private static final float[] SX = new float[N], SY = new float[N], SS = new float[N], SP = new float[N], SV = new float[N];

    static {
        Random r = new Random(7);
        for (int i = 0; i < N; i++) {
            SX[i] = r.nextFloat(); SY[i] = r.nextFloat();
            SS[i] = 0.35f + r.nextFloat() * r.nextFloat() * 1.6f;
            SP[i] = r.nextFloat() * 6.28f; SV[i] = 0.4f + r.nextFloat();
        }
    }

    private Backdrop() {}

    static float time() {
        return (System.nanoTime() / 1_000_000L % 3_600_000L) / 1000f;
    }

    static void draw(GuiGraphics g, int w, int h) {
        Gfx.use(g);
        paint(w, h, Config.bgStyle);
        int bm = Config.weather == 0 || Config.weather == 5 ? 6 : Config.weather;
        Overlay.MENU_A.draw(g, w, h, 5, 0.55f, 0.9f);
        if (Config.bgStyle != 2) Overlay.MENU_B.draw(g, w, h, bm, 0.3f, 0.6f);
        Gfx.use(g);
        vignette(w, h);
    }

    /** Фон под окнами настроек в мире: мягкая тонировка и свечения без полной заливки. */
    static void tint(GuiGraphics g, int w, int h, float a) {
        Gfx.use(g);
        float t = time();
        int acc = Config.color() | 0xFF000000;
        Gfx.rect4(0, 0, w, h, Gfx.rgba(0x07040F, 0.74f * a), Gfx.rgba(0x07040F, 0.70f * a), Gfx.rgba(0x0B0716, 0.80f * a), Gfx.rgba(0x0B0716, 0.84f * a));
        Gfx.orb(w * (0.18f + 0.04f * Mth.sin(t * 0.2f)), h * 0.2f, h * 0.8f, Gfx.a(acc, 0.22f * a));
        Gfx.orb(w * (0.88f + 0.03f * Mth.cos(t * 0.17f)), h * 0.95f, h * 0.8f, Gfx.a(Gfx.shift(acc, 0.1f, 0f, 0f), 0.18f * a));
        dust(w, h, t, 0.8f * a, 60);
    }

    private static void paint(int w, int h, int style) {
        float t = time();
        int acc = Config.color() | 0xFF000000;
        int c1 = acc, c2 = Gfx.shift(acc, 0.12f, 0f, 0f), c3 = Gfx.shift(acc, -0.1f, -0.1f, -0.05f);
        Gfx.rect4(0, 0, w, h, Gfx.mix(0xFF05030C, acc, 0.06f), 0xFF05030C, 0xFF0B0716, Gfx.mix(0xFF080512, c2, 0.08f));
        if (style != 1) {
            Gfx.orb(w * (0.22f + 0.10f * Mth.sin(t * 0.13f)), h * (0.30f + 0.10f * Mth.cos(t * 0.11f)), h * 0.85f, Gfx.a(c1, 0.34f));
            Gfx.orb(w * (0.80f + 0.08f * Mth.cos(t * 0.09f)), h * (0.60f + 0.12f * Mth.sin(t * 0.12f)), h * 0.95f, Gfx.a(c2, 0.26f));
            Gfx.orb(w * (0.50f + 0.22f * Mth.sin(t * 0.07f)), h * 1.02f, h * 0.75f, Gfx.a(c3, 0.30f));
        }
        if (style == 2) return;
        beam(w, h, t, acc);
        wave(w, h, t, 0, h * 0.60f, h * 0.075f, c1, 0.26f);
        wave(w, h, t, 1, h * 0.70f, h * 0.065f, c2, 0.22f);
        wave(w, h, t, 2, h * 0.82f, h * 0.050f, Gfx.mix(c3, 0xFFFFFFFF, 0.25f), 0.18f);
        dust(w, h, t, 1f, N);
    }

    private static void beam(int w, int h, float t, int acc) {
        float sw = 0.04f * w * Mth.sin(t * 0.15f);
        int top = Gfx.a(Gfx.mix(acc, 0xFFFFFFFF, 0.5f), 0.13f), bot = Gfx.a(acc, 0f);
        Gfx.quad(w * 0.06f + sw, 0, top, w * 0.32f + sw, 0, top, w * 0.80f + sw, h, bot, w * 0.38f + sw, h, bot);
        Gfx.quad(w * 0.34f + sw, 0, Gfx.a(top, 0.6f), w * 0.40f + sw, 0, Gfx.a(top, 0.6f), w * 0.95f + sw, h, bot, w * 0.88f + sw, h, bot);
    }

    private static void wave(int w, int h, float t, int layer, float base, float amp, int color, float alpha) {
        float ph = layer * 1.9f;
        int step = 6;
        float prevX = 0, prevY = 0;
        int top = Gfx.a(color, alpha), bot = Gfx.a(color, 0f), glow0 = Gfx.a(0xFFFFFFFF, 0f);
        int crest = Gfx.a(Gfx.mix(color, 0xFFFFFFFF, 0.55f), alpha * 2.4f);
        float th = 3.2f;
        for (int x = 0; x <= w + step; x += step) {
            float y = base + amp * Mth.sin(x * 0.0085f + t * 0.42f + ph) + amp * 0.5f * Mth.sin(x * 0.019f - t * 0.31f + ph * 2f)
                    + amp * 0.25f * Mth.sin(x * 0.0041f + t * 0.17f + ph * 3f);
            if (x > 0) {
                Gfx.quad(prevX, prevY, top, x, y, top, x, h, bot, prevX, h, bot);
                Gfx.quad(prevX, prevY - th, bot, x, y - th, bot, x, y, crest, prevX, prevY, crest);
                Gfx.quad(prevX, prevY, crest, x, y, crest, x, y + th, bot, prevX, prevY + th, bot);
            }
            prevX = x;
            prevY = y;
        }
    }

    private static void dust(int w, int h, float t, float alpha, int count) {
        for (int i = 0; i < Math.min(N, count); i++) {
            float x = ((SX[i] + t * 0.004f * SV[i]) % 1f) * w, y = (SY[i] * h + Mth.sin(t * 0.3f * SV[i] + SP[i]) * 4f);
            float tw = 0.25f + 0.55f * (0.5f + 0.5f * Mth.sin(t * SV[i] * 1.6f + SP[i]));
            int c = Gfx.rgba(i % 5 == 0 ? Config.color() : 0xFFFFFF, tw * alpha);
            Gfx.circle(x, y, SS[i], c);
            if (SS[i] > 1.2f) Gfx.orb(x, y, SS[i] * 5f, Gfx.a(c, 0.22f));
        }
    }

    static void vignette(int w, int h) {
        int dark = 0xB0030207, none = 0x00030207;
        Gfx.rect4(0, 0, w, h * 0.22f, dark, dark, none, none);
        Gfx.rect4(0, h * 0.72f, w, h * 0.28f, none, none, dark, dark);
        Gfx.rect4(0, 0, w * 0.12f, h, 0x80030207, none, 0x80030207, none);
        Gfx.rect4(w * 0.88f, 0, w * 0.12f, h, none, 0x80030207, none, 0x80030207);
    }

    /** Экран загрузки: пульсирующий логотип в свечении, вращающееся кольцо, бегущая полоска и совет. */
    static void loading(GuiGraphics g, int w, int h, String title) {
        Gfx.use(g);
        float t = time();
        int cx = w / 2, cy = h / 2 - 22, acc = Config.color() | 0xFF000000;
        float pulse = 1f + 0.05f * Mth.sin(t * 3.3f);
        Gfx.orb(cx, cy, 90, Gfx.a(acc, 0.28f));
        float ls = 54 * pulse;
        Gfx.use(g);
        Gfx.circleRing(cx, cy, 42, 1f, 0x22FFFFFF);
        float head = t * 4.2f;
        Gfx.arc(cx, cy, 42, 2.4f, head, head + 1.7f, acc);
        Gfx.arc(cx, cy, 42, 2.4f, head + 3.14f, head + 3.6f, Gfx.a(acc, 0.5f));
        String s = Tr.tr(title);
        Gfx.textC(s, cx, cy + 66, 15f, 0xFFFFFFFF, true);
        float bw = 170, bx = cx - bw / 2, by = cy + 86;
        Gfx.rr(bx, by, bw, 4, 2, 0x26FFFFFF);
        float seg = 56, sx = bx + (bw + seg) * ((t % 1.6f) / 1.6f) - seg;
        float x0 = Math.max(bx, sx), x1 = Math.min(bx + bw, sx + seg);
        if (x1 > x0) Gfx.rrH(x0, by, x1 - x0, 4, 2, Gfx.a(acc, 0.3f), acc);
        String tip = Tr.tr(TIPS[(int) ((t / 5f) % TIPS.length)]);
        Gfx.textC(tip, w / 2f, h - 30, Ui.BODY, 0x99FFFFFF, false);
        Gfx.textC("FLR Visuals", w / 2f, h - 16, Ui.BODY - 1f, 0x55FFFFFF, false);
    }
}
