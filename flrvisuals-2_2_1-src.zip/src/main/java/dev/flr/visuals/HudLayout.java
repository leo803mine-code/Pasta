package dev.flr.visuals;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.neoforged.fml.loading.FMLPaths;

/** Положение HUD-виджетов: их можно двигать мышью, пока открыт чат. Смещения хранятся в config/flrvisuals_hud.properties. */
final class HudLayout {
    static final String[] IDS = {"fps", "coords", "watermark", "potions", "hotkeys", "cooldowns", "items", "armor", "target", "media"};
    static final String[] NAMES = {"FPS counter", "Coordinates HUD", "Watermark", "Effects list", "Hotkeys list", "Cooldowns", "Item counter", "Armor HUD", "Target HUD", "Media player"};
    private static final Map<String, float[]> OFF = new HashMap<>(), RECT = new HashMap<>();
    static String dragging;
    private static float grabX, grabY;
    private static boolean loaded;

    private HudLayout() {}

    static boolean editing() {
        return Minecraft.getInstance().screen instanceof ChatScreen;
    }

    static float[] off(String id) {
        if (!loaded) load();
        return OFF.computeIfAbsent(id, k -> new float[2]);
    }

    static float[] rect(String id) {
        return RECT.get(id);
    }

    static void setRect(String id, float x, float y, float w, float h) {
        float[] r = RECT.computeIfAbsent(id, k -> new float[4]);
        r[0] = x; r[1] = y; r[2] = w; r[3] = h;
    }

    static String name(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return NAMES[i];
        return id;
    }

    static String hit(double mx, double my) {
        String best = null;
        for (String id : IDS) {
            float[] r = RECT.get(id);
            if (r == null || !Hud.shown(id)) continue;
            float[] o = off(id);
            if (Ui.in(mx, my, r[0] + o[0], r[1] + o[1], r[2], r[3])) best = id;
        }
        return best;
    }

    static boolean press(double mx, double my, int btn) {
        String id = hit(mx, my);
        if (id == null) return false;
        if (btn == 1) {
            float[] o = off(id);
            o[0] = 0;
            o[1] = 0;
            save();
            return true;
        }
        if (btn != 0) return false;
        float[] r = RECT.get(id), o = off(id);
        dragging = id;
        grabX = (float) mx - (r[0] + o[0]);
        grabY = (float) my - (r[1] + o[1]);
        return true;
    }

    static boolean drag(double mx, double my, int sw, int sh) {
        if (dragging == null) return false;
        float[] r = RECT.get(dragging), o = off(dragging);
        if (r == null) return false;
        float nx = (float) mx - grabX, ny = (float) my - grabY;
        nx = Math.max(2, Math.min(sw - r[2] - 2, nx));
        ny = Math.max(2, Math.min(sh - r[3] - 2, ny));
        float cx = nx + r[2] / 2f;
        if (Math.abs(cx - sw / 2f) < 5) nx = sw / 2f - r[2] / 2f;
        if (nx < 8) nx = 4;
        if (nx + r[2] > sw - 8) nx = sw - r[2] - 4;
        if (ny < 8) ny = 4;
        if (ny + r[3] > sh - 8) ny = sh - r[3] - 4;
        o[0] = nx - r[0];
        o[1] = ny - r[1];
        return true;
    }

    static boolean release() {
        if (dragging == null) return false;
        dragging = null;
        save();
        return true;
    }

    static void resetAll() {
        OFF.clear();
        save();
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("flrvisuals_hud.properties");
    }

    static void load() {
        loaded = true;
        Path p = file();
        if (!Files.exists(p)) return;
        Properties pr = new Properties();
        try (Reader r = Files.newBufferedReader(p)) {
            pr.load(r);
        } catch (Exception e) {
            return;
        }
        for (String id : IDS) {
            try {
                String x = pr.getProperty(id + ".x"), y = pr.getProperty(id + ".y");
                if (x != null && y != null) OFF.put(id, new float[]{Float.parseFloat(x), Float.parseFloat(y)});
            } catch (NumberFormatException ignored) {
            }
        }
    }

    static void save() {
        Properties pr = new Properties();
        for (Map.Entry<String, float[]> e : OFF.entrySet()) {
            pr.setProperty(e.getKey() + ".x", String.valueOf(e.getValue()[0]));
            pr.setProperty(e.getKey() + ".y", String.valueOf(e.getValue()[1]));
        }
        try (Writer w = Files.newBufferedWriter(file())) {
            pr.store(w, "FLR HUD layout");
        } catch (Exception ignored) {
        }
    }
}
