package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.util.Mth;

/**
 * Куртки 2.2: шесть стилей (пуховик, бомбер, худи, косуха, студенческая, парка) с деталями: воротники, молнии,
 * карманы, манжеты, мех. Цвета задаёт стиль, тема или свой оттенок. Координаты в пространстве части модели (y вверх после scale(1,-1,1)).
 */
final class Jackets {
    static int P, S, A;

    private Jackets() {}

    /** Палитра: основной, вторичный и акцентный цвет для стиля. */
    static void palette(int style, int mode, int theme) {
        int[][] def = {
                {0xFF6C3BD0, 0xFF2A1646, 0xFFA879FF}, {0xFF1B1B22, 0xFFFF7A1A, 0xFFE8E8F0}, {0xFF8A93B8, 0xFF4B5273, 0xFFFFFFFF},
                {0xFF131318, 0xFF2C2C36, 0xFFC9CAD6}, {0xFF1E3A8A, 0xFFF2EBDD, 0xFFE0B13A}, {0xFF55663E, 0xFF2E3A24, 0xFFF6F2EA}};
        int[] d = def[Math.max(0, Math.min(5, style))];
        P = d[0]; S = d[1]; A = d[2];
        if (mode == 0) return;
        int base = switch (mode) {
            case 1 -> theme;
            case 2 -> Config.hsb(Config.jacketHue, Config.jacketSat, Config.jacketBri);
            case 3 -> 0xFF000000 | Config.BLACK;
            default -> 0xFF000000 | Config.WHITE;
        };
        P = base;
        S = style == 4 ? Gfx.mix(base, 0xFFFFFFFF, 0.8f) : Pets.shade(base, 0.5f) | 0xFF000000;
        A = mode == 1 ? Gfx.mix(base, 0xFFFFFFFF, 0.55f) : (mode == 3 ? theme : Gfx.mix(base, 0xFFFFFFFF, 0.5f));
    }

    private static int dk(int c, float k) {
        return Pets.shade(c, k) | 0xFF000000;
    }

    static void body(int style) {
        PoseStack ps = Pets.ps;
        ps.pushPose();
        ps.scale(1, -1, 1);
        int dP = dk(P, 0.72f);
        Pets.box(-4.45f, -12.3f, -2.45f, 4.45f, 0.25f, 2.45f, P);
        switch (style) {
            case 0 -> {
                for (int i = 0; i < 4; i++) {
                    float y0 = -12.3f + i * 3.15f;
                    Pets.box(-4.62f, y0 + 0.2f, -2.62f, 4.62f, y0 + 2.9f, 2.62f, P);
                    Pets.box(-4.66f, y0 + 2.9f, -2.66f, 4.66f, y0 + 3.3f, 2.66f, S);
                }
                Pets.box(-3.1f, 0.2f, -2.4f, 3.1f, 1.9f, 2.4f, P);
                Pets.box(-2.7f, 0.5f, -2.0f, 2.7f, 1.95f, 2.0f, S);
                Pets.box(-0.3f, -12.2f, -2.76f, 0.3f, 1.4f, -2.62f, A);
                Pets.box(-3.7f, -7.4f, -2.7f, -1.5f, -7.1f, -2.62f, S);
                Pets.box(1.5f, -7.4f, -2.7f, 3.7f, -7.1f, -2.62f, S);
            }
            case 1 -> {
                Pets.box(-4.5f, -12.5f, -2.55f, 4.5f, -11.1f, 2.55f, S);
                Pets.box(-4.55f, -11.4f, -2.6f, 4.55f, -11.1f, 2.6f, A);
                Pets.box(-3.3f, 0.2f, -2.45f, 3.3f, 1.7f, 2.45f, S);
                Pets.box(-3.35f, 0.9f, -2.5f, 3.35f, 1.15f, 2.5f, A);
                Pets.box(-1.4f, 0.3f, -2.62f, 1.4f, 1.5f, -2.3f, S);
                Pets.box(-0.3f, -11.0f, -2.6f, 0.3f, 0.3f, -2.5f, A);
                Pets.box(-3.6f, -9.4f, -2.58f, -1.4f, -8.9f, -2.5f, S);
                Pets.box(1.4f, -9.4f, -2.58f, 3.6f, -8.9f, -2.5f, S);
                Pets.box(-1.0f, -6.0f, 2.46f, 1.0f, -4.6f, 2.56f, A);
            }
            case 2 -> {
                PetModels.ball(0, 0.9f, 2.5f, 3.7f, 2.6f, 2.5f, P);
                PetModels.ball(0, 1.0f, 1.5f, 2.9f, 1.8f, 1.9f, S);
                Pets.box(-3.3f, -9.6f, -2.66f, 3.3f, -5.7f, -2.5f, dP);
                Pets.box(-4.55f, -12.45f, -2.6f, 4.55f, -11.5f, 2.6f, dP);
                Pets.box(-1.4f, -6.3f, -2.7f, -1.0f, 0.4f, -2.6f, A);
                Pets.box(1.0f, -7.2f, -2.7f, 1.4f, 0.4f, -2.6f, A);
                Pets.box(-1.5f, -6.5f, -2.72f, -0.9f, -6.0f, -2.6f, A);
                Pets.box(0.9f, -7.4f, -2.72f, 1.5f, -6.9f, -2.6f, A);
            }
            case 3 -> {
                Pets.box(-4.5f, -10.6f, -2.52f, 4.5f, -9.8f, 2.52f, S);
                Pets.box(-0.6f, -10.5f, -2.62f, 0.6f, -9.9f, -2.5f, A);
                for (int i = 0; i < 9; i++) {
                    float f = i / 8f, x = Mth.lerp(f, 0.6f, -2.6f), y = Mth.lerp(f, -0.2f, -11.4f);
                    Pets.box(x - 0.28f, y - 0.28f, -2.7f, x + 0.28f, y + 0.28f, -2.5f, A);
                }
                Pets.part(-2.6f, 0.2f, -2.5f, 0, 0, -28f, () -> Pets.box(-1.9f, -4.8f, -0.25f, 0.4f, 0.1f, 0.25f, S));
                Pets.part(2.6f, 0.2f, -2.5f, 0, 0, 28f, () -> Pets.box(-0.4f, -4.8f, -0.25f, 1.9f, 0.1f, 0.25f, S));
                Pets.box(-3.2f, 0.2f, -2.35f, 3.2f, 1.6f, 2.35f, S);
                Pets.box(-3.9f, 0.2f, -2.7f, -2.9f, 0.6f, -2.5f, 0xFFE3B23C);
                Pets.box(2.9f, 0.2f, -2.7f, 3.9f, 0.6f, -2.5f, 0xFFE3B23C);
            }
            case 4 -> {
                Pets.box(-4.55f, -12.5f, -2.58f, 4.55f, -11.0f, 2.58f, S);
                Pets.box(-4.6f, -11.9f, -2.62f, 4.6f, -11.6f, 2.62f, A);
                Pets.box(-3.2f, 0.2f, -2.45f, 3.2f, 1.6f, 2.45f, S);
                Pets.box(-3.25f, 0.6f, -2.5f, 3.25f, 0.9f, 2.5f, A);
                Pets.box(-0.25f, -11.0f, -2.6f, 0.25f, 0.3f, -2.5f, S);
                for (int i = 0; i < 5; i++) PetModels.ball(0, -10.2f + i * 2.4f, -2.6f, 0.38f, 0.38f, 0.2f, A);
                Pets.box(-3.4f, -6.4f, -2.64f, -2.3f, -1.4f, -2.5f, 0xFFD43A3A);
                Pets.box(-3.4f, -2.5f, -2.64f, -0.9f, -1.4f, -2.5f, 0xFFD43A3A);
                Pets.box(-3.4f, -4.3f, -2.64f, -1.4f, -3.4f, -2.5f, 0xFFD43A3A);
            }
            default -> {
                PetModels.ball(0, 1.0f, 2.7f, 3.5f, 3.0f, 2.2f, P);
                for (int i = 0; i < 14; i++) {
                    float a = Mth.TWO_PI * i / 14;
                    PetModels.ball(Mth.cos(a) * 3.7f, 1.2f, Mth.sin(a) * 2.9f, 1.25f, 1.15f, 1.25f, A);
                }
                for (int i = -4; i <= 4; i++) PetModels.ball(i * 1.0f, -12.2f, -2.5f, 0.85f, 0.7f, 0.8f, A);
                Pets.box(-3.7f, -8.2f, -2.64f, -1.5f, -5.4f, -2.5f, S);
                Pets.box(1.5f, -8.2f, -2.64f, 3.7f, -5.4f, -2.5f, S);
                Pets.box(-0.3f, -11.5f, -2.7f, 0.3f, 0.6f, -2.55f, S);
                for (int i = 0; i < 4; i++) Pets.box(-0.6f, -10f + i * 2.8f, -2.76f, 0.6f, -9.5f + i * 2.8f, -2.6f, A);
            }
        }
        Pets.box(-4.0f, -4.8f, 2.4f, 4.0f, 0.4f, 2.5f, 0x00000000);
        ps.popPose();
    }

    static void arm(int style, boolean right) {
        PoseStack ps = Pets.ps;
        ps.pushPose();
        ps.scale(1, -1, 1);
        float x0 = right ? -3.45f : -1.45f, x1 = right ? 1.45f : 3.45f, cx = (x0 + x1) / 2f;
        int sleeve = style == 4 ? S : P, cuff = style == 4 ? P : S;
        Pets.box(x0, -10.4f, -2.45f, x1, 2.4f, 2.45f, sleeve);
        Pets.box(x0 - 0.06f, -10.45f, -2.52f, x1 + 0.06f, -9.2f, 2.52f, cuff);
        switch (style) {
            case 0 -> {
                for (int i = 0; i < 3; i++) Pets.box(x0 - 0.1f, -7.4f + i * 3.1f, -2.56f, x1 + 0.1f, -7.0f + i * 3.1f, 2.56f, S);
            }
            case 1 -> {
                Pets.box(x0 - 0.06f, -10.45f, -2.52f, x1 + 0.06f, -9.9f, 2.52f, A);
                Pets.box(cx - 0.9f, -0.5f, 2.46f, cx + 0.9f, 1.6f, 2.58f, A);
            }
            case 2 -> Pets.box(x0 - 0.06f, -10.45f, -2.52f, x1 + 0.06f, -9.7f, 2.52f, dk(P, 0.7f));
            case 3 -> {
                Pets.box(cx - 0.15f, -8.8f, -2.56f, cx + 0.15f, 1.4f, -2.45f, A);
                Pets.box(x0 - 0.1f, 1.0f, -0.6f, x1 + 0.1f, 1.5f, 0.6f, 0xFFE3B23C);
            }
            case 4 -> {
                Pets.box(x0 - 0.06f, -0.2f, -2.55f, x1 + 0.06f, 0.4f, 2.55f, A);
                Pets.box(x0 - 0.06f, -1.4f, -2.55f, x1 + 0.06f, -0.9f, 2.55f, A);
            }
            default -> {
                for (int i = 0; i < 6; i++) {
                    float a = Mth.TWO_PI * i / 6;
                    PetModels.ball(cx + Mth.cos(a) * 1.9f, -9.9f, Mth.sin(a) * 1.9f, 1.1f, 1.0f, 1.1f, A);
                }
            }
        }
        ps.popPose();
    }
}
