package dev.flr.visuals;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.stream.Stream;
import net.neoforged.fml.loading.FMLPaths;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.openal.ALC10;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.stb.STBVorbisInfo;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

/**
 * Встроенный медиаплеер FLR. Играет .ogg и .wav из папки flrvisuals/music (и из папок, перечисленных в
 * flrvisuals/music_folders.txt) через OpenAL в собственном потоке со своим источником звука. Java Sound не нужен,
 * поэтому плеер работает и на мобильных лаунчерах. Есть перемотка, громкость, повтор, перемешивание,
 * спектр для визуализации и текст песен из .lrc.
 */
final class MediaPlayer {
    static final class Track {
        final String name, artist, title;
        final Path path;
        final boolean builtin;
        final float hue;
        List<Integer> lrcTime = new ArrayList<>();
        List<String> lrcText = new ArrayList<>();

        Track(String name, Path path, boolean builtin) {
            this.name = name;
            this.path = path;
            this.builtin = builtin;
            int i = name.indexOf(" - ");
            if (i > 0) {
                artist = name.substring(0, i).trim();
                title = name.substring(i + 3).trim();
            } else {
                artist = "";
                title = name;
            }
            hue = (Math.abs(name.hashCode()) % 1000) / 1000f;
        }
    }

    static final List<Track> LIST = new ArrayList<>();
    static volatile int index = -1;
    static volatile boolean playing, loading;
    static volatile String error = "";
    static int skippedMp3;

    private static volatile short[] pcm;
    private static int channels = 2, rate = 44100;
    private static volatile int total, readIdx, posFrames;
    private static volatile int seekReq = -1;
    private static volatile boolean endHandled;
    private static Thread thread;
    private static Track pending;
    private static final Object LOCK = new Object();
    private static boolean inited;
    private static final float[] BARS = new float[32];
    private static final float[] RE = new float[1024], IM = new float[1024], WIN = new float[1024];
    private static final Random RND = new Random();

    // OpenAL
    private static final int NBUF = 4, CHUNK = 4096;
    private static long alCtx;
    private static volatile int alSrc;
    private static int[] alBufs;
    private static final ArrayDeque<Integer> FREE = new ArrayDeque<>();
    private static final ArrayDeque<Integer> QUEUED = new ArrayDeque<>();
    private static int baseIdx;
    private static ShortBuffer abuf;

    private MediaPlayer() {}

    static Path folder() {
        return FMLPaths.GAMEDIR.get().resolve("flrvisuals").resolve("music");
    }

    /** Основная папка плюс дополнительные из flrvisuals/music_folders.txt (по одной на строку). */
    static List<Path> folders() {
        Set<Path> res = new LinkedHashSet<>();
        res.add(folder());
        Path cfg = FMLPaths.GAMEDIR.get().resolve("flrvisuals").resolve("music_folders.txt");
        try {
            if (!Files.exists(cfg)) {
                Files.createDirectories(cfg.getParent());
                Files.writeString(cfg, "# One folder per line. Example (Android): /storage/emulated/0/Music\n# Одна папка на строку. Пример (Android): /storage/emulated/0/Music\n", StandardCharsets.UTF_8);
            }
            for (String ln : Files.readAllLines(cfg, StandardCharsets.UTF_8)) {
                String t = ln.trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                try {
                    Path p = Path.of(t);
                    if (Files.isDirectory(p)) res.add(p);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return new ArrayList<>(res);
    }

    static void init() {
        if (inited) return;
        inited = true;
        for (int i = 0; i < 1024; i++) WIN[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / 1023));
        scan();
    }

    static void scan() {
        Track cur = current();
        String curName = cur == null ? null : cur.name;
        List<Track> n = new ArrayList<>();
        if (MediaPlayer.class.getResource("/assets/flrvisuals/sounds/flr_track.ogg") != null) n.add(new Track("FLR Theme", null, true));
        skippedMp3 = 0;
        try {
            Files.createDirectories(folder());
        } catch (Exception ignored) {
        }
        Set<Path> seenFiles = new LinkedHashSet<>();
        for (Path dir : folders()) {
            try (Stream<Path> st = Files.walk(dir, 3)) {
                st.filter(Files::isRegularFile).sorted().forEach(p -> {
                    Path abs = p.toAbsolutePath().normalize();
                    if (!seenFiles.add(abs)) return;
                    String f = p.getFileName().toString(), l = f.toLowerCase(Locale.ROOT);
                    if (l.endsWith(".ogg") || l.endsWith(".oga") || l.endsWith(".wav") || l.endsWith(".wave")) n.add(new Track(f.substring(0, f.lastIndexOf('.')), p, false));
                    else if (l.endsWith(".mp3") || l.endsWith(".flac") || l.endsWith(".m4a") || l.endsWith(".aac") || l.endsWith(".opus")) skippedMp3++;
                });
            } catch (Exception ignored) {
            }
        }
        LIST.clear();
        LIST.addAll(n);
        index = -1;
        if (curName != null) for (int i = 0; i < LIST.size(); i++) if (LIST.get(i).name.equals(curName)) index = i;
    }

    /** Копирует перетащенные в окно файлы в папку плеера и обновляет список. Возвращает число добавленных. */
    static int addFiles(List<Path> files) {
        int ok = 0;
        try {
            Files.createDirectories(folder());
            for (Path p : files) {
                String f = p.getFileName().toString(), l = f.toLowerCase(Locale.ROOT);
                if (!(l.endsWith(".ogg") || l.endsWith(".oga") || l.endsWith(".wav") || l.endsWith(".wave"))) continue;
                Files.copy(p, folder().resolve(f), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                ok++;
            }
        } catch (Exception e) {
            error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        }
        if (ok > 0) scan();
        return ok;
    }

    static Track current() {
        int i = index;
        return i >= 0 && i < LIST.size() ? LIST.get(i) : null;
    }

    /** Открывает папку; если система не умеет (мобильные лаунчеры) — копирует путь в буфер обмена и показывает его. */
    static void openFolder() {
        String path = folder().toAbsolutePath().toString();
        try {
            Files.createDirectories(folder());
            net.minecraft.Util.getPlatform().openFile(folder().toFile());
        } catch (Throwable ignored) {
        }
        try {
            net.minecraft.client.Minecraft.getInstance().keyboardHandler.setClipboard(path);
        } catch (Throwable ignored) {
        }
        Notify.show(Tr.tr("Folder path copied") + ": " + path, 0x8FA8FF);
    }

    // ---------------------------------------------------------------- управление
    static void play(int i) {
        init();
        if (LIST.isEmpty()) return;
        i = Math.floorMod(i, LIST.size());
        index = i;
        playing = true;
        synchronized (LOCK) {
            pending = LIST.get(i);
        }
        start();
    }

    static void toggle() {
        init();
        if (current() == null) {
            play(0);
            return;
        }
        if (pcm == null && !loading) {
            play(index);
            return;
        }
        playing = !playing;
    }

    static void next() {
        init();
        if (LIST.isEmpty()) return;
        if (Config.mediaShuffle && LIST.size() > 1) {
            int n;
            do { n = RND.nextInt(LIST.size()); } while (n == index);
            play(n);
        } else {
            play(index + 1);
        }
    }

    static void prev() {
        init();
        if (LIST.isEmpty()) return;
        if (positionSec() > 3f) seek(0f);
        else play(index - 1);
    }

    static void seek(float frac) {
        if (pcm == null) return;
        int target = (int) (Gfx.clamp01(frac) * total);
        seekReq = target;
        posFrames = target;
        endHandled = false;
    }

    static float positionSec() {
        if (pcm == null || rate == 0) return 0f;
        return Math.max(0, posFrames) / (float) rate;
    }

    static float lengthSec() {
        return pcm == null || rate == 0 ? 0f : total / (float) rate;
    }

    static float progress() {
        float len = lengthSec();
        return len <= 0f ? 0f : Gfx.clamp01(positionSec() / len);
    }

    private static void start() {
        if (thread != null && thread.isAlive()) return;
        thread = new Thread(MediaPlayer::run, "FLR-Media");
        thread.setDaemon(true);
        thread.start();
    }

    // ---------------------------------------------------------------- OpenAL
    private static void ensureAl() {
        long ctx = ALC10.alcGetCurrentContext();
        if (ctx == 0L) throw new IllegalStateException("OpenAL is not available (sound is off?)");
        if (ctx == alCtx && alSrc != 0) return;
        // контекст создан заново (например, перезагрузка звуков) — источник и буферы старого больше недействительны
        alCtx = ctx;
        FREE.clear();
        QUEUED.clear();
        AL10.alGetError();
        alSrc = AL10.alGenSources();
        alBufs = new int[NBUF];
        for (int i = 0; i < NBUF; i++) {
            alBufs[i] = AL10.alGenBuffers();
            FREE.add(alBufs[i]);
        }
        AL10.alSourcei(alSrc, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
        AL10.alSource3f(alSrc, AL10.AL_POSITION, 0f, 0f, 0f);
        AL10.alSourcef(alSrc, AL10.AL_ROLLOFF_FACTOR, 0f);
        int err = AL10.alGetError();
        if (err != AL10.AL_NO_ERROR) {
            alSrc = 0;
            throw new IllegalStateException("OpenAL error " + err);
        }
        if (abuf == null) abuf = MemoryUtil.memAllocShort(CHUNK * 2);
        readIdx = Math.max(0, Math.min(total, posFrames));
        baseIdx = readIdx;
    }

    /** Останавливает источник и возвращает все буферы в пул. Вызывать только из потока плеера. */
    private static void clearAl() {
        if (alSrc == 0 || ALC10.alcGetCurrentContext() != alCtx) return;
        AL10.alSourceStop(alSrc);
        int q = AL10.alGetSourcei(alSrc, AL10.AL_BUFFERS_QUEUED);
        while (q-- > 0) AL10.alSourceUnqueueBuffers(alSrc);
        AL10.alGetError();
        FREE.clear();
        if (alBufs != null) for (int b : alBufs) FREE.add(b);
        QUEUED.clear();
    }

    // ---------------------------------------------------------------- поток воспроизведения
    private static void run() {
        while (true) {
            try {
                Track t;
                synchronized (LOCK) {
                    t = pending;
                    pending = null;
                }
                if (t != null) {
                    load(t);
                    continue;
                }
                short[] p = pcm;
                if (p == null) {
                    Thread.sleep(40);
                    continue;
                }
                ensureAl();
                int ch = channels;
                if (seekReq >= 0) {
                    clearAl();
                    readIdx = Math.min(total, seekReq);
                    baseIdx = readIdx;
                    posFrames = readIdx;
                    seekReq = -1;
                }
                float vol = (float) Config.mediaVolume;
                AL10.alSourcef(alSrc, AL10.AL_GAIN, Math.max(0f, Math.min(1f, vol * vol)));
                int state = AL10.alGetSourcei(alSrc, AL10.AL_SOURCE_STATE);
                if (!playing) {
                    if (state == AL10.AL_PLAYING) AL10.alSourcePause(alSrc);
                    Thread.sleep(30);
                    continue;
                }
                // вернуть проигранные буферы
                int done = AL10.alGetSourcei(alSrc, AL10.AL_BUFFERS_PROCESSED);
                while (done-- > 0) {
                    int b = AL10.alSourceUnqueueBuffers(alSrc);
                    Integer fr = QUEUED.pollFirst();
                    if (fr != null) baseIdx += fr;
                    FREE.add(b);
                }
                // докормить очередь
                int fmt = ch == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
                while (!FREE.isEmpty() && readIdx < total) {
                    int frames = Math.min(CHUNK, total - readIdx);
                    abuf.clear();
                    abuf.put(p, readIdx * ch, frames * ch);
                    abuf.flip();
                    int b = FREE.pollFirst();
                    AL10.alBufferData(b, fmt, abuf, rate);
                    AL10.alSourceQueueBuffers(alSrc, b);
                    QUEUED.add(frames);
                    readIdx += frames;
                }
                state = AL10.alGetSourcei(alSrc, AL10.AL_SOURCE_STATE);
                if (state != AL10.AL_PLAYING && !QUEUED.isEmpty()) AL10.alSourcePlay(alSrc);
                int err = AL10.alGetError();
                if (err != AL10.AL_NO_ERROR) throw new IllegalStateException("OpenAL error " + err);
                int off = AL10.alGetSourcei(alSrc, AL11.AL_SAMPLE_OFFSET);
                posFrames = Math.min(total, baseIdx + Math.max(0, off));
                if (readIdx >= total && QUEUED.isEmpty() && !endHandled) {
                    endHandled = true;
                    posFrames = total;
                    onEnd();
                }
                Thread.sleep(10);
            } catch (InterruptedException e) {
                return;
            } catch (Throwable e) {
                error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                playing = false;
                alSrc = 0; // пересоздадим источник при следующем запуске
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private static void onEnd() {
        if (Config.mediaRepeat == 2) {
            seekReq = 0;
            endHandled = false;
        } else if (Config.mediaShuffle && LIST.size() > 1) {
            next();
        } else if (index + 1 < LIST.size() || Config.mediaRepeat == 1) {
            play(index + 1);
        } else {
            playing = false;
            seekReq = 0;
            endHandled = false;
        }
    }

    private static void load(Track t) {
        loading = true;
        error = "";
        pcm = null;
        try {
            try {
                clearAl();
            } catch (Throwable ignored) {
            }
            int[] meta = new int[2];
            short[] data;
            String fn = t.builtin ? "flr_track.ogg" : t.path.getFileName().toString().toLowerCase(Locale.ROOT);
            if (t.builtin) {
                try (InputStream in = MediaPlayer.class.getResourceAsStream("/assets/flrvisuals/sounds/flr_track.ogg")) {
                    data = decodeOgg(in.readAllBytes(), meta);
                }
            } else if (fn.endsWith(".ogg") || fn.endsWith(".oga")) {
                if (Files.size(t.path) > 250_000_000L) throw new IOException("File is too large");
                data = decodeOgg(Files.readAllBytes(t.path), meta);
            } else {
                data = decodeWav(t.path, meta);
            }
            loadLrc(t);
            channels = meta[0];
            rate = meta[1];
            total = data.length / channels;
            readIdx = 0;
            baseIdx = 0;
            posFrames = 0;
            seekReq = -1;
            endHandled = false;
            pcm = data;
        } catch (Throwable e) {
            error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            playing = false;
            pcm = null;
        } finally {
            loading = false;
        }
    }

    /** Декодирует OGG кусками прямо в итоговый массив (без двойного расхода памяти). Моно или стерео. */
    private static short[] decodeOgg(byte[] data, int[] meta) throws IOException {
        ByteBuffer mem = MemoryUtil.memAlloc(data.length);
        mem.put(data).flip();
        long dec = 0L;
        ShortBuffer tmp = null;
        try (MemoryStack st = MemoryStack.stackPush()) {
            IntBuffer err = st.mallocInt(1);
            dec = STBVorbis.stb_vorbis_open_memory(mem, err, null);
            if (dec == 0L) throw new IOException("Cannot read OGG (" + err.get(0) + ")");
            STBVorbisInfo info = STBVorbisInfo.malloc(st);
            STBVorbis.stb_vorbis_get_info(dec, info);
            int ch = info.channels(), sr = info.sample_rate();
            int len = STBVorbis.stb_vorbis_stream_length_in_samples(dec);
            if (len <= 0) throw new IOException("Empty OGG");
            int oc = Math.min(2, ch);
            if ((long) len * oc > 400_000_000L) throw new IOException("Track is too long");
            short[] out = new short[len * oc];
            final int block = 16384;
            tmp = MemoryUtil.memAllocShort(block * ch);
            int pos = 0;
            while (pos < len) {
                tmp.clear();
                int got = STBVorbis.stb_vorbis_get_samples_short_interleaved(dec, ch, tmp);
                if (got <= 0) break;
                got = Math.min(got, len - pos);
                if (ch == oc) {
                    for (int i = 0; i < got * oc; i++) out[pos * oc + i] = tmp.get(i);
                } else {
                    for (int i = 0; i < got; i++) {
                        out[(pos + i) * 2] = tmp.get(i * ch);
                        out[(pos + i) * 2 + 1] = tmp.get(i * ch + 1);
                    }
                }
                pos += got;
            }
            if (pos <= 0) throw new IOException("Empty OGG");
            if (pos < len) out = java.util.Arrays.copyOf(out, pos * oc);
            meta[0] = oc;
            meta[1] = sr;
            return out;
        } finally {
            if (dec != 0L) STBVorbis.stb_vorbis_close(dec);
            if (tmp != null) MemoryUtil.memFree(tmp);
            MemoryUtil.memFree(mem);
        }
    }

    private static int u16(byte[] b, int o) {
        return (b[o] & 255) | ((b[o + 1] & 255) << 8);
    }

    private static long u32(byte[] b, int o) {
        return (b[o] & 255L) | ((b[o + 1] & 255L) << 8) | ((b[o + 2] & 255L) << 16) | ((b[o + 3] & 255L) << 24);
    }

    private static void readFully(InputStream in, byte[] b, int len) throws IOException {
        int n = 0;
        while (n < len) {
            int r = in.read(b, n, len - n);
            if (r < 0) throw new IOException("Unexpected end of WAV file");
            n += r;
        }
    }

    /**
     * Собственный разбор WAV (без javax.sound): PCM 8/16/24/32 бит, float 32/64, WAVE_FORMAT_EXTENSIBLE.
     * Каналов может быть сколько угодно — берутся первые один или два.
     */
    private static short[] decodeWav(Path p, int[] meta) throws IOException {
        long fileSize = Files.size(p);
        if (fileSize > 400_000_000L) throw new IOException("File is too large");
        try (InputStream in = new BufferedInputStream(Files.newInputStream(p), 1 << 16)) {
            byte[] h = new byte[12];
            readFully(in, h, 12);
            String riff = new String(h, 0, 4, StandardCharsets.US_ASCII), wave = new String(h, 8, 4, StandardCharsets.US_ASCII);
            if (!(riff.equals("RIFF") || riff.equals("RF64")) || !wave.equals("WAVE")) throw new IOException("Not a WAV file");
            int fmtTag = 0, ch = 0, sr = 0, bits = 0, align = 0;
            boolean haveFmt = false;
            long consumed = 12;
            byte[] ch8 = new byte[8];
            while (true) {
                readFully(in, ch8, 8);
                consumed += 8;
                String id = new String(ch8, 0, 4, StandardCharsets.US_ASCII);
                long size = u32(ch8, 4);
                if (id.equals("fmt ")) {
                    int n = (int) Math.min(size, 256);
                    byte[] f = new byte[n];
                    readFully(in, f, n);
                    if (size > n) in.skipNBytes(size - n);
                    fmtTag = u16(f, 0);
                    ch = u16(f, 2);
                    sr = (int) u32(f, 4);
                    align = u16(f, 12);
                    bits = u16(f, 14);
                    if (fmtTag == 0xFFFE && n >= 26) fmtTag = u16(f, 24); // подформат из EXTENSIBLE
                    haveFmt = true;
                    consumed += size;
                    if ((size & 1) == 1) { in.skipNBytes(1); consumed++; }
                } else if (id.equals("data")) {
                    if (!haveFmt) throw new IOException("WAV: no fmt chunk");
                    if (ch < 1 || sr <= 0 || bits <= 0) throw new IOException("WAV: bad format");
                    boolean flt = fmtTag == 3;
                    if (fmtTag != 1 && fmtTag != 3) throw new IOException("Unsupported WAV encoding (" + fmtTag + ")");
                    int bps = bits / 8;
                    if (bps < 1 || bps > 8 || (flt && bps != 4 && bps != 8)) throw new IOException("Unsupported WAV bit depth: " + bits);
                    int frameBytes = Math.max(align, bps * ch);
                    long avail = Math.max(0, fileSize - consumed);
                    long dl = (size == 0 || size > avail) ? avail : size;
                    long frames = dl / frameBytes;
                    int oc = Math.min(2, ch);
                    if (frames <= 0) throw new IOException("Empty WAV");
                    if (frames * oc > 400_000_000L) throw new IOException("Track is too long");
                    short[] out = new short[(int) frames * oc];
                    int blockFrames = 8192;
                    byte[] blk = new byte[blockFrames * frameBytes];
                    long done = 0;
                    while (done < frames) {
                        int nf = (int) Math.min(blockFrames, frames - done);
                        readFully(in, blk, nf * frameBytes);
                        for (int i = 0; i < nf; i++) {
                            for (int c = 0; c < oc; c++) {
                                int o = i * frameBytes + c * bps;
                                short v;
                                if (flt) {
                                    double d = bps == 4 ? Float.intBitsToFloat((int) u32(blk, o)) : Double.longBitsToDouble(u32(blk, o) | (u32(blk, o + 4) << 32));
                                    v = (short) Math.max(-32768, Math.min(32767, Math.round(d * 32767.0)));
                                } else if (bps == 1) {
                                    v = (short) (((blk[o] & 255) - 128) << 8);
                                } else {
                                    v = (short) (((blk[o + bps - 1]) << 8) | (blk[o + bps - 2] & 255));
                                }
                                out[(int) (done + i) * oc + c] = v;
                            }
                        }
                        done += nf;
                    }
                    meta[0] = oc;
                    meta[1] = sr;
                    return out;
                } else {
                    in.skipNBytes(size + (size & 1));
                    consumed += size + (size & 1);
                }
            }
        }
    }

    private static void loadLrc(Track t) {
        t.lrcTime = new ArrayList<>();
        t.lrcText = new ArrayList<>();
        if (t.path == null) return;
        String f = t.path.getFileName().toString();
        Path lrc = t.path.resolveSibling(f.substring(0, f.lastIndexOf('.')) + ".lrc");
        if (!Files.exists(lrc)) return;
        try {
            List<int[]> tmp = new ArrayList<>();
            List<String> txt = new ArrayList<>();
            for (String ln : Files.readAllLines(lrc, StandardCharsets.UTF_8)) {
                int end = 0;
                List<Integer> times = new ArrayList<>();
                while (end < ln.length() && ln.charAt(end) == '[') {
                    int c = ln.indexOf(']', end);
                    if (c < 0) break;
                    String tag = ln.substring(end + 1, c);
                    int col = tag.indexOf(':');
                    if (col > 0 && Character.isDigit(tag.charAt(0))) {
                        try {
                            int mm = Integer.parseInt(tag.substring(0, col));
                            double ss = Double.parseDouble(tag.substring(col + 1));
                            times.add((int) (mm * 60000 + ss * 1000));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                    end = c + 1;
                }
                String text = ln.substring(end).trim();
                for (int tm : times) {
                    tmp.add(new int[]{tm, txt.size()});
                    txt.add(text);
                }
            }
            tmp.sort((a, b) -> Integer.compare(a[0], b[0]));
            for (int[] e : tmp) {
                t.lrcTime.add(e[0]);
                t.lrcText.add(txt.get(e[1]));
            }
        } catch (Exception ignored) {
        }
    }

    /** Индекс текущей строки текста песни или -1. */
    static int lyricIndex() {
        Track t = current();
        if (t == null || t.lrcTime.isEmpty()) return -1;
        int ms = (int) (positionSec() * 1000f), r = -1;
        for (int i = 0; i < t.lrcTime.size(); i++) {
            if (t.lrcTime.get(i) <= ms) r = i;
            else break;
        }
        return r;
    }

    // ---------------------------------------------------------------- спектр для визуализации
    /** 32 полосы 0..1, сглаженные; вызывать раз в кадр. */
    static float[] spectrum(float dt) {
        short[] p = pcm;
        boolean live = p != null && playing && !loading && alSrc != 0;
        if (live) {
            int start = (int) (positionSec() * rate);
            int ch = channels;
            for (int i = 0; i < 1024; i++) {
                int f = start + i;
                float s = 0f;
                if (f >= 0 && f < total) {
                    s = p[f * ch] / 32768f;
                    if (ch == 2) s = (s + p[f * ch + 1] / 32768f) * 0.5f;
                }
                RE[i] = s * WIN[i];
                IM[i] = 0f;
            }
            fft();
            for (int b = 0; b < BARS.length; b++) {
                float lo = 2f + (float) Math.pow(380.0 / 2.0, b / (double) BARS.length) * 2f - 2f;
                float hi = 2f + (float) Math.pow(380.0 / 2.0, (b + 1) / (double) BARS.length) * 2f - 2f;
                int i0 = Math.max(1, (int) lo), i1 = Math.max(i0 + 1, (int) hi);
                float m = 0f;
                for (int i = i0; i < i1 && i < 512; i++) m = Math.max(m, (float) Math.sqrt(RE[i] * RE[i] + IM[i] * IM[i]));
                float v = Gfx.clamp01((float) Math.pow(m / 60f * (1f + b * 0.12f), 0.55));
                BARS[b] = v > BARS[b] ? Gfx.lerp(BARS[b], v, 0.6f) : BARS[b] - dt * 1.6f;
                if (BARS[b] < 0f) BARS[b] = 0f;
            }
        } else {
            for (int b = 0; b < BARS.length; b++) BARS[b] = Math.max(0f, BARS[b] - dt * 1.2f);
        }
        return BARS;
    }

    private static void fft() {
        int n = 1024;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                float tr = RE[i]; RE[i] = RE[j]; RE[j] = tr;
                float ti = IM[i]; IM[i] = IM[j]; IM[j] = ti;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2 * Math.PI / len;
            float wr = (float) Math.cos(ang), wi = (float) Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                float cr = 1f, ci = 0f;
                for (int k = 0; k < len / 2; k++) {
                    int a = i + k, b = i + k + len / 2;
                    float xr = RE[b] * cr - IM[b] * ci, xi = RE[b] * ci + IM[b] * cr;
                    RE[b] = RE[a] - xr; IM[b] = IM[a] - xi;
                    RE[a] += xr; IM[a] += xi;
                    float nr = cr * wr - ci * wi;
                    ci = cr * wi + ci * wr;
                    cr = nr;
                }
            }
        }
    }

    static String time(float sec) {
        int s = Math.max(0, (int) sec);
        return (s / 60) + ":" + String.format(Locale.ROOT, "%02d", s % 60);
    }
}
