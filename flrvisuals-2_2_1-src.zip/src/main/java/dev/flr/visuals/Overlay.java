package dev.flr.visuals;

import java.util.Random;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Собственные частицы поверх экрана (без ванильных частиц): снежинки, дождь, лепестки, пепел, звёзды и кубы. */
final class Overlay {
    static final Overlay HUD = new Overlay(240), MENU_A = new Overlay(110), MENU_B = new Overlay(40);

    private final int max;
    private final float[] x, y, d, p;
    private final Random rnd = new Random(11);
    private long last;

    private Overlay(int max) {
        this.max = max;
        x = new float[max]; y = new float[max]; d = new float[max]; p = new float[max];
        for (int i = 0; i < max; i++) {
            x[i] = rnd.nextFloat(); y[i] = rnd.nextFloat(); d[i] = 0.25f + rnd.nextFloat() * 0.75f; p[i] = rnd.nextFloat() * 6.28f;
        }
    }

    /** mode: 1 снег, 2 дождь, 3 лепестки, 4 пепел, 5 звёзды, 6 кубы. */
    void draw(GuiGraphics g, int w, int h, int mode, float amount, float alpha) {
        if (mode <= 0 || alpha <= 0.01f) return;
        Gfx.use(g);
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.1f, (now - last) / 1e9f);
        if (dt < 0.0005f) dt = 0f;
        last = now;
        float t = (now / 1_000_000_000L % 100000L) + (now % 1_000_000_000L) / 1e9f;
        int n = Math.min(max, 10 + (int) (Mth.clamp(amount, 0f, 1f) * (max - 10)));
        int acc = Config.color() & 0xFFFFFF;
        for (int i = 0; i < n; i++) {
            float dd = d[i], vx, vy;
            switch (mode) {
                case 1 -> { vy = 0.045f + 0.07f * dd; vx = Mth.sin(t * 0.7f + p[i]) * 0.012f; }
                case 2 -> { vy = 0.9f + 0.5f * dd; vx = -0.09f; }
                case 3 -> { vy = 0.06f + 0.04f * dd; vx = Mth.sin(t * 0.9f + p[i]) * 0.03f; }
                case 4 -> { vy = 0.03f + 0.03f * dd; vx = Mth.sin(t + p[i]) * 0.01f; }
                case 5 -> { vy = -0.004f; vx = 0.002f; }
                default -> { vy = 0.025f + 0.03f * dd; vx = Mth.sin(t * 0.4f + p[i]) * 0.01f; }
            }
            x[i] += vx * dt;
            y[i] += vy * dt;
            if (y[i] > 1.08f) { y[i] = -0.08f; x[i] = rnd.nextFloat(); }
            if (y[i] < -0.1f) y[i] = 1.08f;
            if (x[i] < -0.05f) x[i] += 1.1f;
            if (x[i] > 1.05f) x[i] -= 1.1f;
            float px = x[i] * w, py = y[i] * h;
            float a = alpha * (0.3f + 0.6f * dd);
            switch (mode) {
                case 1 -> flake(px, py, 1.2f + dd * 3.2f, a);
                case 2 -> Gfx.line(px, py, px - 1.2f - dd * 1.2f, py + 5f + dd * 9f, 0.9f, Gfx.rgba(0xAEC9FF, a * 0.8f));
                case 3 -> petal(px, py, 1.6f + dd * 2.2f, p[i], p[i] > 3.1f ? 0xFFB7D5 : 0xFF8FBF, a, t);
                case 4 -> Gfx.circle(px, py, 0.5f + dd * 1.1f, Gfx.rgba(0xA6A6B2, a * (0.6f + 0.4f * Mth.sin(t * 3f + p[i]))));
                case 5 -> star(px, py, 1f + dd * 2.2f, (i % 4 == 0) ? acc : 0xFFFFFF, a * (0.35f + 0.65f * (float) Math.pow(0.5 + 0.5 * Mth.sin(t * 1.8f + p[i] * 3f), 2)));
                default -> cube(px, py, 2f + dd * 3.4f, acc, a * 0.7f);
            }
        }
    }

    private static void flake(float x, float y, float r, float a) {
        int col = Gfx.rgba(0xFFFFFF, a);
        Gfx.circle(x, y, r * 0.55f, col);
        if (r > 2.2f) {
            for (int k = 0; k < 3; k++) {
                float an = k * Mth.PI / 3f, dx = Mth.cos(an) * r, dy = Mth.sin(an) * r;
                Gfx.line(x - dx, y - dy, x + dx, y + dy, 0.7f, Gfx.a(col, 0.8f));
            }
        }
        if (r > 3f) Gfx.orb(x, y, r * 2.6f, Gfx.a(col, 0.12f));
    }

    private static void petal(float x, float y, float s, float ph, int rgb, float a, float t) {
        float an = ph + t * 0.8f, ca = Mth.cos(an), sa = Mth.sin(an);
        Gfx.line(x - ca * s, y - sa * s, x + ca * s, y + sa * s, s * 1.1f, Gfx.rgba(rgb, a));
    }

    private static void star(float x, float y, float r, int rgb, float a) {
        int col = Gfx.rgba(rgb, a);
        Gfx.icon(Gfx.SPARK, x, y, r * 2.6f, col);
        Gfx.orb(x, y, r * 3.2f, Gfx.a(col, 0.18f));
    }

    /** Изометрический кубик из трёх граней. */
    private static void cube(float cx, float cy, float s, int rgb, float a) {
        int top = Gfx.rgba(mul(rgb, 1.0f), a), left = Gfx.rgba(mul(rgb, 0.5f), a), right = Gfx.rgba(mul(rgb, 0.72f), a);
        float hx = s, hy = s * 0.5f;
        Gfx.quad(cx, cy - hy * 2, top, cx + hx, cy - hy, top, cx, cy, top, cx - hx, cy - hy, top);
        Gfx.quad(cx - hx, cy - hy, left, cx, cy, left, cx, cy + s, left, cx - hx, cy + s - hy, left);
        Gfx.quad(cx, cy, right, cx + hx, cy - hy, right, cx + hx, cy + s - hy, right, cx, cy + s, right);
    }

    private static int mul(int rgb, float k) {
        int r = Math.min(255, (int) ((rgb >> 16 & 255) * k + 40 * k)), gg = Math.min(255, (int) ((rgb >> 8 & 255) * k + 40 * k)), b = Math.min(255, (int) ((rgb & 255) * k + 40 * k));
        return r << 16 | gg << 8 | b;
    }
}
