package dev.flr.visuals;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Target ESP: красивый крутящийся прицел (новогодний стиль) на существе, на которое вы навели прицел. */
final class TargetEsp {
    private static final double RANGE = 32.0;
    private static LivingEntity target, shown;
    private static float alpha, sx, sy, sr;
    private static long lastNs;

    private TargetEsp() {}

    static void tick(Minecraft mc) {
        target = null;
        if (!Config.master || !Config.targetEsp || mc.player == null || mc.level == null || mc.screen != null) return;
        var pl = mc.player;
        Vec3 eye = pl.getEyePosition(), look = pl.getViewVector(1f), end = eye.add(look.scale(RANGE));
        AABB box = pl.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(pl, eye, end, box,
                e -> e instanceof LivingEntity && e != pl && !e.isSpectator() && e.isPickable(), RANGE * RANGE);
        if (hit != null && hit.getEntity() instanceof LivingEntity le) target = le;
    }

    private static void dot(GuiGraphics g, float x, float y, int size, int rgb, float a) {
        Gfx.use(g);
        Gfx.circle(x, y, size / 2f, Gfx.rgba(rgb, a));
    }

    static void render(GuiGraphics g, float pt) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        alpha += ((target != null ? 1f : 0f) - alpha) * Math.min(1f, dt * 10f);
        boolean fresh = false;
        if (target != null) {
            if (shown != target) fresh = true;
            shown = target;
        }
        if (shown == null) return;
        if (target == null && alpha < 0.03f || !shown.isAlive()) { shown = null; return; }

        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 p = new Vec3(Mth.lerp(pt, shown.xo, shown.getX()), Mth.lerp(pt, shown.yo, shown.getY()) + shown.getBbHeight() * 0.5,
                Mth.lerp(pt, shown.zo, shown.getZ()));
        Vec3 d = p.subtract(cam.getPosition());
        Vector3f l = cam.getLeftVector(), u = cam.getUpVector(), f = cam.getLookVector();
        double z = d.x * f.x() + d.y * f.y() + d.z * f.z();
        if (z < 0.3) return;
        double xr = -(d.x * l.x() + d.y * l.y() + d.z * l.z()), yu = d.x * u.x() + d.y * u.y() + d.z * u.z();
        int W = g.guiWidth(), H = g.guiHeight();
        double tan = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        float tx = (float) (W / 2.0 + xr / (z * tan * W / (double) H) * (W / 2.0));
        float ty = (float) (H / 2.0 - yu / (z * tan) * (H / 2.0));
        float tr = Mth.clamp((float) (shown.getBbHeight() / (z * tan) * H / 2.0) * 0.6f * (float) Config.espSize, 16f, 90f);
        if (fresh || sr == 0f) { sx = tx; sy = ty; sr = tr; }
        float k = Math.min(1f, dt * 18f);
        sx += (tx - sx) * k; sy += (ty - sy) * k; sr += (tr - sr) * k;

        float t = (now / 1_000_000_000f) % 1000f;
        boolean xmas = Config.espStyle == 0;
        int c1 = xmas ? 0xE53A47 : (Config.color() & 0xFFFFFF), c2 = xmas ? 0xFFFFFF : 0xFFFFFF;
        float pulse = 1f + 0.05f * Mth.sin(t * 4f), r = sr * pulse;

        Gfx.use(g);
        Gfx.glow(sx - r, sy - r, r * 2, r * 2, r, 12, Gfx.rgba(c1, alpha * 0.07f));
        Gfx.circleRing(sx, sy, r * 1.12f, 0.9f, Gfx.rgba(c2, alpha * 0.28f));
        for (int arc = 0; arc < 4; arc++) {
            float base = t * 1.7f + arc * Mth.HALF_PI;
            int col = arc % 2 == 0 ? c1 : c2;
            Gfx.arc(sx, sy, r, 3f, base - 0.5f, base, Gfx.rgba(col, alpha * 0.28f));
            Gfx.arc(sx, sy, r, 3.2f, base, base + 0.8f, Gfx.rgba(col, alpha));
        }
        for (int kx = 0; kx < 4; kx++) {
            float ang = -t * 1.2f + kx * Mth.HALF_PI;
            float cx = sx + Mth.cos(ang) * r * 0.62f, cy = sy + Mth.sin(ang) * r * 0.62f;
            Gfx.line(cx - 3.2f, cy, cx + 3.2f, cy, 1.1f, Gfx.rgba(c2, alpha * 0.9f));
            Gfx.line(cx, cy - 3.2f, cx, cy + 3.2f, 1.1f, Gfx.rgba(c2, alpha * 0.9f));
            Gfx.circle(cx, cy, 1.1f, Gfx.rgba(c1, alpha));
        }
        float cr = 4f + Mth.sin(t * 5f);
        for (int kx = 0; kx < 4; kx++) {
            float ang = t * 2.4f + kx * Mth.HALF_PI;
            Gfx.circle(sx + Mth.cos(ang) * cr, sy + Mth.sin(ang) * cr, 1.4f, Gfx.rgba(kx % 2 == 0 ? c1 : c2, alpha));
        }
        String s = shown.getDisplayName().getString() + "  " + String.format("%.1f", shown.getHealth()) + " HP";
        float w = Ui.w(s) + 18, x0 = sx - w / 2f, y0 = sy + r + 8;
        Gfx.glow(x0, y0 + 1, w, 16, 8, 8, Gfx.rgba(0x000000, 0.3f * alpha));
        Gfx.rrV(x0, y0, w, 16, 8, Gfx.rgba(0x1E1832, 0.9f * alpha), Gfx.rgba(0x0E0B1C, 0.9f * alpha));
        Gfx.ring(x0, y0, w, 16, 8, 1f, Gfx.rgba(c1, 0.6f * alpha));
        Gfx.textC(s, sx, y0 + 8, Ui.BODY, Gfx.rgba(0xFFFFFF, alpha), false);
    }
}
