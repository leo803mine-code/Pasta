package dev.flr.visuals;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.Minecraft;

/**
 * Перевод интерфейса мода. Английский текст служит ключом: "Wing settings" -> flrvisuals.ui.wing_settings.
 * Если перевода нет, показывается исходный английский текст. Язык: Config.lang (0 = как в игре, 1 = English, 2 = Русский).
 */
public final class Tr {
    private static final Map<String, String> RU = load("ru_ru");
    private static final Map<String, String> CACHE = new HashMap<>();
    private static boolean lastRu;

    private Tr() {}

    private static Map<String, String> load(String lang) {
        Map<String, String> m = new HashMap<>();
        try (Reader r = new InputStreamReader(Tr.class.getResourceAsStream("/assets/flrvisuals/lang/" + lang + ".json"), StandardCharsets.UTF_8)) {
            JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
            o.entrySet().forEach(e -> m.put(e.getKey(), e.getValue().getAsString()));
        } catch (Exception ignored) {
        }
        return m;
    }

    public static boolean russian() {
        if (Config.lang == 1) return false;
        if (Config.lang == 2) return true;
        try {
            return Minecraft.getInstance().getLanguageManager().getSelected().toLowerCase(Locale.ROOT).startsWith("ru");
        } catch (Exception e) {
            return false;
        }
    }

    public static String key(String s) {
        String k = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
        return "flrvisuals.ui." + k;
    }

    public static String tr(String s) {
        if (s == null) return "";
        boolean ru = russian();
        if (ru != lastRu) {
            CACHE.clear();
            lastRu = ru;
        }
        if (!ru) return s;
        String c = CACHE.get(s);
        if (c == null) {
            c = RU.getOrDefault(key(s), s);
            CACHE.put(s, c);
        }
        return c;
    }

    public static String fmt(String s, Object... args) {
        try {
            return String.format(tr(s), args);
        } catch (Exception e) {
            return s;
        }
    }
}
